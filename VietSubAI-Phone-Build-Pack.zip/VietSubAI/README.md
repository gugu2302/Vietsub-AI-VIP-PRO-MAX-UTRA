# VietSub AI Android prototype

Android Kotlin prototype and a sample Python backend for an online video-subtitle workflow.

## Current status
This is a starter prototype, not a complete AI video editor. It does not yet perform AI removal/inpainting of old subtitles, translation, Vietnamese TTS voice-over, or final video muxing end-to-end. Those features require implementation and a configured/hosted backend with suitable AI services.

## Build APK
See [BUILD-APK-ON-PHONE.md](BUILD-APK-ON-PHONE.md) for instructions to use GitHub Actions from an Android phone. The workflow is in `.github/workflows/build-apk.yml`.
