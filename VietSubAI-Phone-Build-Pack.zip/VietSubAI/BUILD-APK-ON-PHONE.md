# Build VietSub AI APK using only an Android phone

> Important: this builds the current Android prototype. It does NOT yet implement the full AI subtitle removal, translation, Vietnamese voice-over, or video export pipeline. The backend is a separate component and needs hosting/configuration.

## Steps
1. Download and extract this ZIP on your phone (or upload the ZIP contents to a new GitHub repository using GitHub's mobile website; GitHub does not run a build directly from an uploaded ZIP).
2. Create a repository on GitHub, for example `VietSubAI`.
3. Upload the contents of the `VietSubAI` project folder to the repository root. Ensure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab. If asked, enable workflows.
5. Choose **Build VietSub AI APK** and tap **Run workflow** (or push to `main`).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `VietSubAI-debug-apk`.
8. Extract the artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/file manager.

## Build details
- Requires Android SDK platform 35 and Java 17 (provided by GitHub Actions).
- The output is a debug APK for testing, not a Play Store release.
- Only install APKs from a repository you control and trust.
