package com.vietsubai.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private var videoUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var server: EditText
    private val pickVideo = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28, 32, 28, 24)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        root.addView(TextView(this).apply { text = "VietSub AI"; textSize = 30f; gravity = Gravity.CENTER; setPadding(0,0,0,12) })
        root.addView(TextView(this).apply { text = "Dịch video • Phụ đề Việt • Giọng đọc"; textSize = 16f; gravity = Gravity.CENTER; setPadding(0,0,0,24) })
        server = EditText(this).apply { hint = "Địa chỉ máy chủ, ví dụ http://192.168.1.10:8000"; setSingleLine(true); setText("http://10.0.2.2:8000") }
        root.addView(server, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply { text = "① Chọn video"; setOnClickListener { chooseVideo() } }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 })
        root.addView(Button(this).apply { text = "② Tải lên và xử lý"; setOnClickListener { uploadVideo() } }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        status = TextView(this).apply { text = "Chọn video để bắt đầu. Cần máy chủ xử lý video đang chạy."; textSize = 15f; setPadding(0,24,0,0) }
        root.addView(status)
        root.addView(TextView(this).apply { text = "MVP: ứng dụng gửi video tới backend. Kết quả tải về sẽ được bổ sung theo API máy chủ. Không nhập API key bí mật vào ứng dụng."; textSize = 12f; setPadding(0,24,0,0) })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(intent, pickVideo)
    }

    @Deprecated("Deprecated in Android API but kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == RESULT_OK) {
            videoUri = data?.data
            videoUri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            status.text = if (videoUri != null) "Đã chọn video. Nhấn Tải lên và xử lý." else "Chưa chọn video."
        }
    }

    private fun uploadVideo() {
        val uri = videoUri ?: run { status.text = "Bạn hãy chọn video trước."; return }
        val base = server.text.toString().trim().trimEnd('/')
        if (!base.startsWith("http://") && !base.startsWith("https://")) { status.text = "Địa chỉ máy chủ không hợp lệ."; return }
        status.text = "Đang tải video lên máy chủ…"
        thread {
            try {
                val boundary = "----VietSubAI${System.currentTimeMillis()}"
                val conn = (URL("$base/process").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; doOutput = true; connectTimeout = 15000; readTimeout = 60000
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                }
                DataOutputStream(conn.outputStream).use { out ->
                    out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"video.mp4\"\r\nContent-Type: video/mp4\r\n\r\n")
                    contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out) } ?: error("Không đọc được video")
                    out.writeBytes("\r\n--$boundary--\r\n")
                }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                runOnUiThread { status.text = "Máy chủ trả về HTTP $code\n$body" }
                conn.disconnect()
            } catch (e: Exception) { runOnUiThread { status.text = "Không kết nối được: ${e.message}\nKiểm tra địa chỉ máy chủ và backend." } }
        }
    }
}
